a = 10
b = 20
c = a + b
print(c)
Sonuc = a + b + c
print("Test")
print(Sonuc)
